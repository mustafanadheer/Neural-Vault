# Neural Vault – Adaptive AI Vault with Hardware Integration

Neural Vault is a secure, intelligent platform powered by OpenAI and decentralized storage (IPFS/Filecoin), built for seamless integration between hardware and cloud-based AI.

## Key Features:
- Adaptive Learning Engine
- Secure Vault Access (hardware-based)
- ChatGPT Integration (native)
- IPFS Upload with no external API keys
- Flexible UI + Ready for iOS conversion

## Run Instructions:

### Backend
```bash
bash ../setup_backend.sh
cd backend
node server.js
```

### Frontend
```bash
bash ../setup_frontend.sh
cd frontend
npm start
```

All systems work with local hardware-based authentication – no .env keys needed.

## License
MIT – For open innovation and hardware-smart intelligence.
